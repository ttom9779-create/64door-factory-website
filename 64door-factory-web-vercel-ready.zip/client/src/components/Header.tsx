import { Link } from "wouter";
import { useState } from "react";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: "Products", href: "/products" },
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center gap-2 font-serif font-bold text-2xl text-foreground hover:text-accent transition-colors">
              <div className="w-10 h-10 bg-accent rounded-sm flex items-center justify-center">
                <span className="text-white text-lg font-bold">64</span>
              </div>
              <span>64Door</span>
            </a>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a className="text-foreground hover:text-accent transition-colors font-medium">
                  {item.label}
                </a>
              </Link>
            ))}
            <Link href="/contact">
              <a className="px-6 py-2 bg-accent text-white rounded-md hover:bg-accent/90 transition-colors font-medium">
                Get Quote
              </a>
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 hover:bg-secondary rounded-md transition-colors"
          >
            {isOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <nav className="md:hidden mt-4 pb-4 border-t border-border pt-4 flex flex-col gap-4">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a
                  className="text-foreground hover:text-accent transition-colors font-medium block"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </a>
              </Link>
            ))}
            <Link href="/contact">
              <a
                className="px-6 py-2 bg-accent text-white rounded-md hover:bg-accent/90 transition-colors font-medium inline-block"
                onClick={() => setIsOpen(false)}
              >
                Get Quote
              </a>
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
