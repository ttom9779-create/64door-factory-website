import { Link } from "wouter";
import { ArrowRight, Check } from "lucide-react";

export default function Products() {
  const products = [
    {
      name: "PureLine",
      tagline: "Functional Elegance",
      description: "The PureLine range is designed for functional applications where simplicity, elegance and fit-for-purpose are the essentials. This door range is 'pure' in look and feel characterized by smooth, clean surfaces and edges, supplied in a flawless white finish, complemented by European quality fittings as standard.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/product-showcase-pure-5H68PsChMtduXkQrCU3sju.webp",
      features: [
        "Smooth white spray painted finish",
        "European quality fittings",
        "Customizable frame widths (68mm, 92mm, 128mm)",
        "Multiple panel options",
        "Suitable for apartments, institutions, commercial spaces",
      ],
      colors: ["White"],
      applications: ["Apartment buildings", "Institutional buildings", "Individual homes", "Commercial spaces"],
    },
    {
      name: "SmoothLine",
      tagline: "Wood Grain Sophistication",
      description: "The 64Door SmoothLine is the entry-point to the range of rich wood grain surface finishes on smooth melamine continuous pressed laminate that is impact and scratch resistant. This line is very suitable for middle to high end buildings where the wooden feel is essential with a taste of style.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/product-showcase-wood-6s6aHhzzgbSBPwu4RJdBdY.webp",
      features: [
        "Rich wood grain finishes",
        "Impact and scratch resistant",
        "Smooth melamine laminate",
        "European quality fittings",
        "Fully customizable",
      ],
      colors: ["Oak", "Walnut", "Cherry"],
      applications: ["Middle to high-end residentials", "Offices", "Hotels", "Commercial spaces"],
    },
    {
      name: "OpenLine",
      tagline: "Natural Texture",
      description: "The Openline product range takes the wooden look and feel to a new level by introducing a sense of texture to the door surface by use of scratch and impact resistant high pressure melamine laminate. If you are looking to get a balance of the natural yet sophisticated look for wood, then the OpenLine range offers exactly that.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/product-showcase-wood-6s6aHhzzgbSBPwu4RJdBdY.webp",
      features: [
        "Textured wood surfaces",
        "High-pressure melamine laminate",
        "Scratch and impact resistant",
        "Natural yet sophisticated look",
        "Versatile design options",
      ],
      colors: ["Oregon Pine", "Dark Lady"],
      applications: ["Middle to high-end residentials", "Offices", "Hotels", "High-traffic areas"],
    },
    {
      name: "MatrixLine",
      tagline: "Exotic Luxury",
      description: "The MatrixLine is the ultimate choice in the 64Door Factory Range for a truly natural, exotic wooden impression. This range brings it all together providing deeply textured, wood grained surfaces that are impact and scratch resistant. The MatrixLine of products are at home where luxury, aesthetics and class are essential over and above function.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/product-showcase-matrix-krNKr4hysv7fo7zviSWfmL.webp",
      features: [
        "Exotic wood impressions",
        "3D textured surfaces",
        "Deeply wood-grained finish",
        "Impact and scratch resistant",
        "Premium aesthetic",
      ],
      colors: ["Marbella", "Noce Leuca", "Wenge"],
      applications: ["Luxury residentials", "High-end commercial", "Premium offices", "Boutique hotels"],
    },
  ];

  const colorInfo = [
    { name: "White", description: "Pure and timeless. Creates a refreshing, clean, stylish appearance." },
    { name: "Oak", description: "Warm light tan-brown. Versatile and easy to match with interior design." },
    { name: "Walnut", description: "Rich beautiful color. Develops a natural, evolved look in your home." },
    { name: "Cherry", description: "Warm golden-brown tones. Makes spaces feel cozier and warmer." },
    { name: "Oregon Pine", description: "Light tone for refreshing, clean look. Combines well with neutral colors." },
    { name: "Dark Lady", description: "Elegant and bold. Perfect for creating modern and sophisticated spaces." },
    { name: "Marbella", description: "Cool sandy brown. Induces naturalness and comfort while adding depth." },
    { name: "Noce Leuca", description: "Cool brown spectrum. Blends well with cool greys, blues, and yellows." },
    { name: "Wenge", description: "Rich brown with copper undertones. Nearly black streaks with coarse texture." },
  ];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="py-16 bg-background border-b border-border">
        <div className="container mx-auto px-4">
          <h1 className="font-serif text-5xl font-bold mb-4 text-foreground">
            Our Product Lines
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl">
            Four distinct collections designed to meet the specific needs of every segment, from functional to luxury.
          </p>
        </div>
      </section>

      {/* Product Details */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          {products.map((product, index) => (
            <div
              key={product.name}
              className={`mb-20 pb-20 ${index !== products.length - 1 ? "border-b border-border" : ""}`}
            >
              <div className={`grid md:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? "md:grid-cols-2 md:auto-cols-fr" : ""}`}>
                {/* Content */}
                <div className={index % 2 === 1 ? "md:order-2" : ""}>
                  <div className="mb-2">
                    <span className="text-accent font-semibold text-sm uppercase tracking-wider">
                      {product.tagline}
                    </span>
                  </div>
                  <h2 className="font-serif text-4xl font-bold mb-6 text-foreground">
                    {product.name}
                  </h2>
                  <p className="text-lg text-gray-700 mb-8 leading-relaxed">
                    {product.description}
                  </p>

                  <div className="mb-8">
                    <h3 className="font-serif text-xl font-bold mb-4 text-foreground">
                      Key Features
                    </h3>
                    <ul className="space-y-2">
                      {product.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-3 text-gray-700">
                          <Check className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="grid grid-cols-2 gap-6 mb-8">
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Available Colors</h4>
                      <p className="text-gray-600 text-sm">
                        {product.colors.join(", ")}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Best For</h4>
                      <p className="text-gray-600 text-sm">
                        {product.applications.slice(0, 2).join(", ")}
                      </p>
                    </div>
                  </div>

                  <Link href="/contact">
                    <a className="inline-flex items-center gap-2 px-6 py-3 bg-accent text-white rounded-md hover:bg-accent/90 transition-colors font-semibold group">
                      Request Samples
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </a>
                  </Link>
                </div>

                {/* Image */}
                <div className={index % 2 === 1 ? "md:order-1" : ""}>
                  <div className="h-96 rounded-lg overflow-hidden shadow-lg">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Color Range Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="font-serif text-5xl font-bold mb-4 text-foreground text-center">
            Color Range
          </h2>
          <p className="text-xl text-gray-600 text-center mb-16 max-w-2xl mx-auto">
            Choose from our curated selection of colors, each carefully designed to complement different interior styles and preferences.
          </p>

          <div className="grid md:grid-cols-3 gap-6">
            {colorInfo.map((color) => (
              <div
                key={color.name}
                className="p-6 bg-white rounded-lg border border-border hover:border-accent transition-colors"
              >
                <h3 className="font-serif text-lg font-bold mb-2 text-foreground">
                  {color.name}
                </h3>
                <p className="text-gray-700 text-sm leading-relaxed">
                  {color.description}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-12 p-8 bg-white rounded-lg border border-border">
            <p className="text-center text-gray-600 text-sm">
              <strong>Note:</strong> For orders above 300 doors, other color specifications are possible. Please contact us for custom color inquiries.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-foreground text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-serif text-5xl font-bold mb-6">
            Find Your Perfect Door
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Our team is ready to help you select the perfect door solution for your project.
          </p>
          <Link href="/contact">
            <a className="inline-block px-8 py-4 bg-accent text-white rounded-md hover:bg-accent/90 transition-colors font-semibold">
              Contact Our Team
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
