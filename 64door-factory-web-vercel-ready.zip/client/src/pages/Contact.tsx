import { useState } from "react";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { toast } from "sonner";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    subject: "",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Show success message
    toast.success("Message sent successfully! We'll get back to you soon.");
    // Reset form
    setFormData({
      name: "",
      email: "",
      phone: "",
      company: "",
      subject: "",
      message: "",
    });
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Location",
      details: ["Nairobi, Kenya"],
    },
    {
      icon: Phone,
      title: "Phone",
      details: ["+254 (0) XXX XXX XXX"],
    },
    {
      icon: Mail,
      title: "Email",
      details: ["info@64door.com"],
    },
    {
      icon: Clock,
      title: "Business Hours",
      details: ["Monday - Friday: 8:00 AM - 5:00 PM", "Saturday: 9:00 AM - 1:00 PM"],
    },
  ];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="py-16 bg-background border-b border-border">
        <div className="container mx-auto px-4">
          <h1 className="font-serif text-5xl font-bold mb-4 text-foreground">
            Get in Touch
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl">
            Have questions about our products or services? We'd love to hear from you. Contact our team today.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-16">
            {contactInfo.map((info) => {
              const Icon = info.icon;
              return (
                <div
                  key={info.title}
                  className="p-6 bg-background rounded-lg border border-border hover:border-accent transition-colors text-center"
                >
                  <Icon className="w-8 h-8 text-accent mx-auto mb-4" />
                  <h3 className="font-serif text-lg font-bold mb-3 text-foreground">
                    {info.title}
                  </h3>
                  <div className="space-y-1">
                    {info.details.map((detail) => (
                      <p key={detail} className="text-gray-700 text-sm">
                        {detail}
                      </p>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Form */}
            <div>
              <h2 className="font-serif text-3xl font-bold mb-8 text-foreground">
                Send us a Message
              </h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-accent"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-accent"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Phone
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-accent"
                      placeholder="+254 (0) XXX XXX XXX"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Company
                    </label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-accent"
                      placeholder="Your Company"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Subject *
                  </label>
                  <select
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-accent"
                  >
                    <option value="">Select a subject</option>
                    <option value="product-inquiry">Product Inquiry</option>
                    <option value="quote">Request a Quote</option>
                    <option value="wholesale">Wholesale/Bulk Order</option>
                    <option value="installation">Installation Services</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Message *
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                    placeholder="Tell us about your project or inquiry..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-accent text-white rounded-md hover:bg-accent/90 transition-colors font-semibold"
                >
                  Send Message
                </button>
              </form>
            </div>

            {/* Info */}
            <div>
              <h2 className="font-serif text-3xl font-bold mb-8 text-foreground">
                Why Contact Us?
              </h2>
              <div className="space-y-6">
                <div>
                  <h3 className="font-serif text-xl font-bold mb-2 text-foreground">
                    Product Inquiries
                  </h3>
                  <p className="text-gray-700">
                    Learn more about our product lines, specifications, and customization options. Our team can help you find the perfect door solution for your project.
                  </p>
                </div>

                <div>
                  <h3 className="font-serif text-xl font-bold mb-2 text-foreground">
                    Custom Quotes
                  </h3>
                  <p className="text-gray-700">
                    Get personalized pricing for your specific requirements. We offer competitive rates for projects of all sizes, from individual homes to large commercial installations.
                  </p>
                </div>

                <div>
                  <h3 className="font-serif text-xl font-bold mb-2 text-foreground">
                    Installation Support
                  </h3>
                  <p className="text-gray-700">
                    Our team provides comprehensive installation guidance and support to ensure your doors are properly installed and perform optimally.
                  </p>
                </div>

                <div>
                  <h3 className="font-serif text-xl font-bold mb-2 text-foreground">
                    Wholesale & Bulk Orders
                  </h3>
                  <p className="text-gray-700">
                    For architects, builders, and retailers, we offer special pricing and dedicated support for bulk orders and ongoing partnerships.
                  </p>
                </div>

                <div className="p-6 bg-accent/10 rounded-lg border border-accent/20 mt-8">
                  <p className="text-gray-700">
                    <strong>Response Time:</strong> We typically respond to inquiries within 24 hours during business days.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section (Placeholder) */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="font-serif text-3xl font-bold mb-8 text-foreground text-center">
            Visit Our Facility
          </h2>
          <div className="h-96 rounded-lg overflow-hidden shadow-lg bg-gray-200 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="w-16 h-16 text-accent mx-auto mb-4" />
              <p className="text-gray-600 font-semibold">
                Nairobi, Kenya
              </p>
              <p className="text-gray-500 text-sm mt-2">
                Contact us for directions and facility tours
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="font-serif text-4xl font-bold mb-16 text-foreground text-center">
            Frequently Asked Questions
          </h2>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                q: "What is the lead time for custom orders?",
                a: "Lead times vary depending on the complexity and volume of your order. Contact us for specific timelines.",
              },
              {
                q: "Do you offer installation services?",
                a: "Yes, we provide comprehensive installation support and can recommend certified installers in your area.",
              },
              {
                q: "What is your warranty policy?",
                a: "All 64Door products come with a comprehensive warranty. Contact us for detailed warranty information.",
              },
              {
                q: "Can I customize the colors and finishes?",
                a: "Absolutely! We offer extensive customization options. For orders above 300 doors, special color specifications are available.",
              },
              {
                q: "Do you serve international markets?",
                a: "Yes, we serve East African and European markets. Contact us to discuss your specific location.",
              },
            ].map((faq, index) => (
              <div
                key={index}
                className="p-6 bg-white rounded-lg border border-border hover:border-accent transition-colors"
              >
                <h3 className="font-semibold text-foreground mb-2">
                  {faq.q}
                </h3>
                <p className="text-gray-700">
                  {faq.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
