import { Link } from "wouter";
import { ArrowRight, Check } from "lucide-react";

export default function Home() {
  const productLines = [
    {
      name: "PureLine",
      description: "Minimalist elegance with smooth white finish. Perfect for functional applications where simplicity and clean design are essential.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/product-showcase-pure-5H68PsChMtduXkQrCU3sju.webp",
      features: ["Smooth white finish", "European fittings", "Customizable options"],
    },
    {
      name: "SmoothLine",
      description: "Rich wood grain finishes on smooth melamine. Entry-point to natural wood aesthetics with impact and scratch resistance.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/product-showcase-wood-6s6aHhzzgbSBPwu4RJdBdY.webp",
      features: ["Wood grain finishes", "Impact resistant", "Middle to high-end"],
    },
    {
      name: "OpenLine",
      description: "Textured wood surfaces with sophisticated look and feel. Balances natural aesthetics with high-traffic durability.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/product-showcase-wood-6s6aHhzzgbSBPwu4RJdBdY.webp",
      features: ["Textured surfaces", "Scratch resistant", "Versatile design"],
    },
    {
      name: "MatrixLine",
      description: "Ultimate luxury with exotic wood impressions. Deeply textured 3D surfaces for premium residential and commercial spaces.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/product-showcase-matrix-krNKr4hysv7fo7zviSWfmL.webp",
      features: ["Exotic wood impressions", "3D textures", "Premium aesthetic"],
    },
  ];

  const benefits = [
    {
      title: "Artisan Craftsmanship",
      description: "Every door reflects passion, creativity, and European design heritage combined with precision manufacturing.",
    },
    {
      title: "Quality Materials",
      description: "Finest raw materials carefully selected and tested. First-class, reputed ironmongery for lasting durability.",
    },
    {
      title: "Design Flexibility",
      description: "Customizable solutions for every segment—from affordable to luxury, residential to commercial.",
    },
    {
      title: "International Standards",
      description: "All products meet East African and European quality conformance standards as minimum commitment.",
    },
  ];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/hero-factory-RJXLYf3T2t3gPh25vAntWc.webp')",
          }}
        >
          <div className="absolute inset-0 bg-black/40" />
        </div>

        {/* Diagonal Divider SVG */}
        <svg
          className="absolute bottom-0 left-0 w-full h-32 text-background"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
        >
          <path
            d="M0,50 L1200,0 L1200,120 L0,120 Z"
            fill="currentColor"
          />
        </svg>

        <div className="relative z-10 container mx-auto px-4 text-center text-white max-w-3xl">
          <h1 className="font-serif text-6xl md:text-7xl font-bold mb-6 leading-tight">
            Premium Door Solutions
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-100">
            Artisan craftsmanship meets European design heritage. State-of-the-art manufacturing for doors that elevate every space.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/products">
              <a className="px-8 py-4 bg-accent text-white rounded-md hover:bg-accent/90 transition-colors font-semibold flex items-center justify-center gap-2 group">
                Explore Products
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
            </Link>
            <Link href="/contact">
              <a className="px-8 py-4 bg-white text-foreground rounded-md hover:bg-gray-100 transition-colors font-semibold">
                Get a Quote
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-serif text-5xl font-bold mb-6 text-foreground">
                About 64Door Factory
              </h2>
              <p className="text-lg text-gray-700 mb-4 leading-relaxed">
                Founded in 2016, 64Door Factory emerged from the vision of three wood industry professionals with over 45 years of combined experience. We've built a state-of-the-art manufacturing facility in Nairobi that combines precision technology with artisan craftsmanship.
              </p>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                Our mission is to offer customers an unmatched combination of price, reliability, flexibility, and quality through intelligent design, manufacturing excellence, and seamless installation.
              </p>
              <Link href="/about">
                <a className="text-accent font-semibold flex items-center gap-2 hover:gap-3 transition-all">
                  Learn more about us
                  <ArrowRight className="w-5 h-5" />
                </a>
              </Link>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663490895025/8sWjChzxhSDAiUscun4oLA/team-craftsmanship-hZdGVtKVtTVCzZytT2GhsG.webp"
                alt="Craftsmanship"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Product Lines Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-5xl font-bold mb-4 text-foreground">
              Our Product Lines
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Four distinct collections designed to meet the specific needs of every segment, from affordable to luxury.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {productLines.map((product, index) => (
              <div
                key={product.name}
                className={`flex flex-col ${index % 2 === 1 ? "md:flex-row-reverse" : "md:flex-row"} gap-8 items-center`}
              >
                <div className="flex-1">
                  <h3 className="font-serif text-3xl font-bold mb-3 text-foreground">
                    {product.name}
                  </h3>
                  <p className="text-gray-700 mb-6 leading-relaxed">
                    {product.description}
                  </p>
                  <ul className="space-y-2 mb-6">
                    {product.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-gray-700">
                        <Check className="w-5 h-5 text-accent flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link href="/products">
                    <a className="text-accent font-semibold inline-flex items-center gap-2 hover:gap-3 transition-all">
                      View details
                      <ArrowRight className="w-5 h-5" />
                    </a>
                  </Link>
                </div>
                <div className="flex-1 h-80 rounded-lg overflow-hidden shadow-lg">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-foreground text-white">
        <div className="container mx-auto px-4">
          <h2 className="font-serif text-5xl font-bold mb-16 text-center">
            Why Choose 64Door Factory
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {benefits.map((benefit) => (
              <div
                key={benefit.title}
                className="p-8 border border-gray-700 rounded-lg hover:border-accent transition-colors"
              >
                <h3 className="font-serif text-2xl font-bold mb-3">
                  {benefit.title}
                </h3>
                <p className="text-gray-300 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-serif text-5xl font-bold mb-6 text-foreground">
            Ready to Transform Your Space?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Contact our team to discuss your door requirements and get a personalized quote.
          </p>
          <Link href="/contact">
            <a className="inline-block px-8 py-4 bg-accent text-white rounded-md hover:bg-accent/90 transition-colors font-semibold">
              Get in Touch
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
